local iup = require("iuplua")

-- Sidebar for basic instructions
local sidebar_label = iup.label {
    title = "Editor Instructions:\n\n- Type your code in the editor.\n- Save your work as needed.\n- Test and run your scripts!",
    alignment = "ALEFT",
    font = "Arial, 12",
    expand = "VERTICAL",
    fgcolor = "255 255 255",
    bgcolor = "40 40 60",
    padding = "10x10",
}

local sidebar = iup.vbox {
    sidebar_label,
    size = "200x",
    bgcolor = "40 40 60",
    expand = "VERTICAL",
}

-- Code Editor Text Area
local code_editor = iup.text {
    value = "-- Start coding here\nprint('Hello, Lua!')",
    multiline = "YES",
    expand = "YES",
    font = "Courier New, 12",
    bgcolor = "30 30 30",
    fgcolor = "200 200 200",
    wordwrap = "NO",
    border = "YES",
    scrollbar = "YES",
}

-- Buttons for actions
local run_button = iup.button {
    title = "Run Code",
    size = "80x25",
}

local clear_button = iup.button {
    title = "Clear Code",
    size = "80x25",
}

local save_button = iup.button {
    title = "Save File",
    size = "80x25",
}

local console_button = iup.button {
    title = "Open Console UI",
    size = "120x25",
}

-- Console UI Function
local console_output -- Declare outside for scope
local function console_ui()
    console_output = iup.multiline {
        value = "Welcome to the Console UI!\n--------------------------\n",
        readonly = "YES",
        expand = "YES",
        font = "Courier New, 12",
        bgcolor = "30 30 30",
        fgcolor = "200 200 200",
        scrollbar = "YES",
    }

    local console_input = iup.text {
        multiline = "NO",
        font = "Courier New, 12",
        bgcolor = "40 40 60",
        fgcolor = "255 255 255",
        expand = "HORIZONTAL",
        value = "",
    }

    function console_input:k_any(key)
        if key == iup.K_CR then -- Enter key pressed
            local input = self.value
            console_output.append = "> " .. input .. "\n"

            if input == "exit" then
                iup.Destroy(self.dialog)
            elseif input == "" then
                console_output.append = "Please type something or enter 'exit' to quit.\n"
            else
                -- Attempt to execute input as Lua code
                local chunk, err = load(input)
                if chunk then
                    local success, result = pcall(chunk)
                    if success and result then
                        console_output.append = tostring(result) .. "\n"
                    elseif not success then
                        console_output.append = "Error: " .. tostring(result) .. "\n"
                    end
                else
                    console_output.append = "Error: " .. tostring(err) .. "\n"
                end
            end

            self.value = "" -- Clear the input field
        end
    end

    local console_layout = iup.vbox {
        console_output,
        console_input,
        alignment = "ACENTER",
        margin = "10x10",
        gap = "5",
    }

    local console_dialog = iup.dialog {
        console_layout,
        title = "Console UI",
        size = "400x300",
        bgcolor = "30 30 30",
    }

    console_input.dialog = console_dialog -- For cleanup when "exit" is typed
    console_dialog:showxy(iup.CENTER, iup.CENTER)
end

-- Override Lua's print to redirect to the console
local original_print = print
print = function(...)
    local output = ""
    for i, v in ipairs({...}) do
        output = output .. tostring(v)
        if i < select("#", ...) then
            output = output .. "\t"
        end
    end
    if console_output then
        console_output.append = output .. "\n"
    end
    original_print(output) -- Still log to standard output
end

-- Button actions
function run_button:action()
    local code = code_editor.value
    print("Running Code:")
    print(code)
    local chunk, err = load(code)
    if chunk then
        local success, result = pcall(chunk)
        if not success then
            iup.Message("Error", "Error running code:\n" .. result)
        end
    else
        iup.Message("Error", "Failed to load code:\n" .. err)
    end
end

function clear_button:action()
    code_editor.value = ""
end

function save_button:action()
    local file = io.open("saved_code.lua", "w")
    if file then
        file:write(code_editor.value)
        file:close()
        iup.Message("Save Successful", "Your code has been saved to 'saved_code.lua'.")
    else
        iup.Message("Save Error", "Unable to save your file.")
    end
end

function console_button:action()
    console_ui()
end

-- Action Buttons Layout
local button_box = iup.hbox {
    run_button,
    clear_button,
    save_button,
    console_button,
    alignment = "ACENTER",
    margin = "10x10",
    gap = 5,
}

-- Combine Editor and Buttons
local editor_area = iup.vbox {
    code_editor,
    button_box,
    expand = "YES",
}

-- Main Layout
local main_layout = iup.hbox {
    sidebar,
    editor_area,
}

-- Dialog (Window)
local dialog = iup.dialog {
    main_layout,
    title = "Lua Code Editor",
    size = "800x500",
    bgcolor = "20 20 20",
    resizable = "YES",
}

-- Show Dialog
dialog:showxy(iup.CENTER, iup.CENTER)

if iup.MainLoopLevel() == 0 then
    iup.MainLoop()
end
